import React from 'react';
import ReactDOM from 'react-dom';
import {receiveAllPokemon} from './actions/pokemon_actions.js'
import {fetchAllPokemon} from './util/api_util.js'

window.receiveAllPokemon = receiveAllPokemon;
window.fetchAllPokemon = fetchAllPokemon;

import configureStore from "./store/store.js";

const store = configureStore();
window.getState = store.getState; 
window.dispatch = store.dispatch;
document.addEventListener('DOMContentLoaded', () => {
  const rootEl = document.getElementById('root');

  ReactDOM.render(<h1>Pokedex</h1>, rootEl);
});


getState(); // should return initial app state

const getSuccess = pokemon => dispatch(receiveAllPokemon(pokemon));
fetchAllPokemon().then(getSuccess);

getState(); 

// const getSuccess = pokemon => console.log(receiveAllPokemon(pokemon));
// fetchAllPokemon().then(getSuccess);
// console.log(getSuccess)