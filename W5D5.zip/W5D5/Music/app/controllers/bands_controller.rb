class BandsController < ApplicationController
end
