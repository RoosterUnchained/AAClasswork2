class SessionsController < ApplicationController
    def new
    end

    def create
      user = User.find_by_credentials(params[:user][:username], [:user][:password])
      if user.save 
        login(user)
        # redirect_to reddit_clone_url
      else
        flash[:errors] = User.errors.full_messages
        render :new
      end
    end

    def destroy
      log_out
    end

end
