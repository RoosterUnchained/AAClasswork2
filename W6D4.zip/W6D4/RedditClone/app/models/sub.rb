class Sub < ApplicationRecord

    belongs_to :user
    foreign_key: :moderator
    class_name: :User
end
