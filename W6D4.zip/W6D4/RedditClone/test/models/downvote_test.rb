require 'test_helper'

class DownvoteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
