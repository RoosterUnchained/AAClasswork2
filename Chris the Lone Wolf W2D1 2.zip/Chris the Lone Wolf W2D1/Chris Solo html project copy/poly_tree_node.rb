def initialize(value)
  @parent = nil
  @children = []
end

def parent 
  @parent 
end

def children
  @children
end