class ShortenedUrl < ApplicationRecord

end