
a = []

p a.object_id

a << 1

p a.object_id