class Board

  def initialize
  
  end

  def move(start, end)

  end

  def valid?(start, end)
    #checks if the starting and ending towers are valid
  end

  def turn
    #gets player input
  end

  def won?

  end

end